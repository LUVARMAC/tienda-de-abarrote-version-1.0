﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class VentaE
    {
        public string _IDVenta { get; set; }
        public DateTime _FechaVenta { get; set; }
        public int _Cantidad { get; set; }
        public decimal _PrecioUnitario { get; set; }
        public decimal _PrecioTotal { get; set; }
        public string _IDTipo { get; set; }
    }
}
