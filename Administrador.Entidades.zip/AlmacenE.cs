﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class AlmacenE
    {
        public string _IDProduccion { get; set; }
        public string _IDVenta { get; set; }
        public int _Cantidad { get; set; }
        public decimal _PrecioUnitario { get; set; }
        public decimal _IDCompra { get; set; }
        public string _IDAlmacen { get; set; }
    }
}
