﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class LoginE
    {
        public string _IDUsuario { get; set; }
        public string _Usuario { get; set; }
        public string _Password { get; set; }
    }
}
