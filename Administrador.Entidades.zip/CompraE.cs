﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class CompraE
    {
        public string _IDCompra { get; set; }
        public string _NBolFac { get; set; }
        public DateTime _FechaEntrega { get; set; }
        public int _Cantidad { get; set; }
        public decimal _PrecioUnitario { get; set; }
        public decimal _PrecioTotal { get; set; }
        public string _NombreProvedor { get; set; }
        public string _IDTipo { get; set; }
    }
}
