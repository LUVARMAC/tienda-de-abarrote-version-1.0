﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public class ProductoE
    {
        public string _IDProducto { get; set; }
        public string _NombreProducto { get; set; }
        public string _Descripcion { get; set; }
        public int _PrecioUnitario { get; set; }
        public int _Stock { get; set; }
    }
}
